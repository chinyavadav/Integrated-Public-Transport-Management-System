-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2019 at 01:57 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iptfcs`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbldeposits`
--

CREATE TABLE `tbldeposits` (
  `fldid` int(11) NOT NULL,
  `fldphoneno` int(11) NOT NULL,
  `fldamount` int(11) DEFAULT NULL,
  `fldtimestamp` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldeposits`
--

INSERT INTO `tbldeposits` (`fldid`, `fldphoneno`, `fldamount`, `fldtimestamp`) VALUES
(1, 782135087, 100, '1535197296'),
(2, 782135087, 3000, '1536832060');

-- --------------------------------------------------------

--
-- Table structure for table `tbloperators`
--

CREATE TABLE `tbloperators` (
  `fldoperatorid` varchar(10) NOT NULL,
  `fldphoneno` int(11) NOT NULL,
  `fldoperator` varchar(20) NOT NULL,
  `fldcontactperson` varchar(50) NOT NULL,
  `fldcategory` varchar(30) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbloperators`
--

INSERT INTO `tbloperators` (`fldoperatorid`, `fldphoneno`, `fldoperator`, `fldcontactperson`, `fldcategory`, `fldpassword`) VALUES
('OP1842426V', 733346223, 'Pamushana Africa', 'John Doe', 'Commuter Omnibus Service', '5f4dcc3b5aa765d61d8327deb882cf99'),
('OP1884644A', 782135087, 'City Link', 'John Moyo', 'Bus Service', '5f4dcc3b5aa765d61d8327deb882cf99');

-- --------------------------------------------------------

--
-- Table structure for table `tblpassengers`
--

CREATE TABLE `tblpassengers` (
  `fldphoneno` int(11) NOT NULL,
  `fldnfc` varchar(100) DEFAULT NULL,
  `fldfirstname` varchar(20) DEFAULT NULL,
  `fldlastname` varchar(20) DEFAULT NULL,
  `fldbalance` int(11) DEFAULT NULL,
  `fldstatus` varchar(20) NOT NULL,
  `fldpassword` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpassengers`
--

INSERT INTO `tblpassengers` (`fldphoneno`, `fldnfc`, `fldfirstname`, `fldlastname`, `fldbalance`, `fldstatus`, `fldpassword`) VALUES
(782135087, '', 'Victor', 'Chinyavada', 2750, 'Active', '5f4dcc3b5aa765d61d8327deb882cf99');

-- --------------------------------------------------------

--
-- Table structure for table `tblsettlements`
--

CREATE TABLE `tblsettlements` (
  `fldid` int(11) NOT NULL,
  `fldoperatorid` varchar(10) NOT NULL,
  `fldamount` int(11) DEFAULT NULL,
  `fldstart` varchar(20) DEFAULT NULL,
  `fldend` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsettlements`
--

INSERT INTO `tblsettlements` (`fldid`, `fldoperatorid`, `fldamount`, `fldstart`, `fldend`) VALUES
(1, 'OP1884644A', 1000, '1500000000000', '1500000000000');

-- --------------------------------------------------------

--
-- Table structure for table `tblterminals`
--

CREATE TABLE `tblterminals` (
  `fldoperatorid` varchar(10) NOT NULL,
  `fldterminalid` int(11) NOT NULL,
  `fldname` varchar(50) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblterminals`
--

INSERT INTO `tblterminals` (`fldoperatorid`, `fldterminalid`, `fldname`, `fldstatus`, `fldpassword`) VALUES
('OP1884644A', 782135087, 'John Moyo', 'Active', '25d55ad283aa400af464c76d713c07ad');

-- --------------------------------------------------------

--
-- Table structure for table `tbltickets`
--

CREATE TABLE `tbltickets` (
  `fldticketid` varchar(10) NOT NULL,
  `fldtripid` int(11) NOT NULL,
  `fldphoneno` int(11) NOT NULL,
  `fldamount` int(11) DEFAULT NULL,
  `fldtype` varchar(20) NOT NULL,
  `fldtimestamp` varchar(20) DEFAULT NULL,
  `fldstatus` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltickets`
--

INSERT INTO `tbltickets` (`fldticketid`, `fldtripid`, `fldphoneno`, `fldamount`, `fldtype`, `fldtimestamp`, `fldstatus`) VALUES
('T18232601J', 1, 782135087, 50, 'qr-scanner', '1536832085000', ''),
('T18574987Y', 1, 782135087, 50, 'qr-scanner', '1535197307000', ''),
('T18641264F', 2, 782135087, 200, 'qr-scanner', '1543487903000', ''),
('T18855464Y', 1, 782135087, 50, 'qr-scanner', '1536831965000', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbltrips`
--

CREATE TABLE `tbltrips` (
  `fldtripid` int(11) NOT NULL,
  `fldterminalid` int(11) NOT NULL,
  `fldamount` int(11) DEFAULT NULL,
  `fldfrom` varchar(20) DEFAULT NULL,
  `fldto` varchar(20) DEFAULT NULL,
  `fldtimestamp` varchar(20) DEFAULT NULL,
  `fldstatus` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltrips`
--

INSERT INTO `tbltrips` (`fldtripid`, `fldterminalid`, `fldamount`, `fldfrom`, `fldto`, `fldtimestamp`, `fldstatus`) VALUES
(1, 782135087, 50, 'DZ', 'Town', '1535195715000', 'complete'),
(2, 782135087, 200, 'Gweru ', 'Kwekwe', '1543487890000', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `fldemail` varchar(64) NOT NULL,
  `fldfirstname` varchar(20) DEFAULT NULL,
  `fldlastname` varchar(20) DEFAULT NULL,
  `fldaccesslevel` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`fldemail`, `fldfirstname`, `fldlastname`, `fldaccesslevel`, `fldpassword`) VALUES
('admin@iptfcs.co.zw', 'Gary', 'Mucheto', 'Administrator', '5f4dcc3b5aa765d61d8327deb882cf99');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbldeposits`
--
ALTER TABLE `tbldeposits`
  ADD PRIMARY KEY (`fldid`),
  ADD KEY `fldphoneno` (`fldphoneno`);

--
-- Indexes for table `tbloperators`
--
ALTER TABLE `tbloperators`
  ADD PRIMARY KEY (`fldoperatorid`),
  ADD UNIQUE KEY `fldphoneno` (`fldphoneno`);

--
-- Indexes for table `tblpassengers`
--
ALTER TABLE `tblpassengers`
  ADD PRIMARY KEY (`fldphoneno`),
  ADD UNIQUE KEY `fldidentifier` (`fldnfc`);

--
-- Indexes for table `tblsettlements`
--
ALTER TABLE `tblsettlements`
  ADD PRIMARY KEY (`fldid`),
  ADD KEY `fldoperatorid` (`fldoperatorid`);

--
-- Indexes for table `tblterminals`
--
ALTER TABLE `tblterminals`
  ADD PRIMARY KEY (`fldterminalid`),
  ADD KEY `fldoperatorid` (`fldoperatorid`);

--
-- Indexes for table `tbltickets`
--
ALTER TABLE `tbltickets`
  ADD PRIMARY KEY (`fldticketid`),
  ADD KEY `fldtripid` (`fldtripid`),
  ADD KEY `fldphoneno` (`fldphoneno`);

--
-- Indexes for table `tbltrips`
--
ALTER TABLE `tbltrips`
  ADD PRIMARY KEY (`fldtripid`),
  ADD KEY `fldterminalid` (`fldterminalid`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`fldemail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbldeposits`
--
ALTER TABLE `tbldeposits`
  MODIFY `fldid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblsettlements`
--
ALTER TABLE `tblsettlements`
  MODIFY `fldid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbltrips`
--
ALTER TABLE `tbltrips`
  MODIFY `fldtripid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbldeposits`
--
ALTER TABLE `tbldeposits`
  ADD CONSTRAINT `tbldeposits_ibfk_1` FOREIGN KEY (`fldphoneno`) REFERENCES `tblpassengers` (`fldphoneno`);

--
-- Constraints for table `tblsettlements`
--
ALTER TABLE `tblsettlements`
  ADD CONSTRAINT `tblsettlements_ibfk_1` FOREIGN KEY (`fldoperatorid`) REFERENCES `tbloperators` (`fldoperatorid`);

--
-- Constraints for table `tblterminals`
--
ALTER TABLE `tblterminals`
  ADD CONSTRAINT `tblterminals_ibfk_1` FOREIGN KEY (`fldoperatorid`) REFERENCES `tbloperators` (`fldoperatorid`);

--
-- Constraints for table `tbltickets`
--
ALTER TABLE `tbltickets`
  ADD CONSTRAINT `tbltickets_ibfk_1` FOREIGN KEY (`fldtripid`) REFERENCES `tbltrips` (`fldtripid`),
  ADD CONSTRAINT `tbltickets_ibfk_2` FOREIGN KEY (`fldphoneno`) REFERENCES `tblpassengers` (`fldphoneno`);

--
-- Constraints for table `tbltrips`
--
ALTER TABLE `tbltrips`
  ADD CONSTRAINT `tbltrips_ibfk_1` FOREIGN KEY (`fldterminalid`) REFERENCES `tblterminals` (`fldterminalid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
