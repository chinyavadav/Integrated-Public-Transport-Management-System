<?php
	include("connection.php");
    if(isset($_GET["type"]) && isset($_GET["phoneno"])){
        $trips=array();
        $type=mysqli_real_escape_string($conn,$_GET["type"]);
        $phoneno=mysqli_real_escape_string($conn,$_GET["phoneno"]);
        if($type=="today"){
            $today=date('Y-m-d');
            $timestamp=strtotime($today)+"000";
            $statement="SELECT * FROM tbltickets JOIN tbltrips ON tbltickets.fldtripid=tbltrips.fldtripid WHERE tbltickets.fldphoneno='$phoneno' and tbltickets.fldtimestamp>'$timestamp' ORDER BY tbltickets.fldtimestamp DESC";
        }else{
            $statement="SELECT * FROM tbltickets JOIN tbltrips ON tbltickets.fldtripid=tbltrips.fldtripid WHERE tbltickets.fldphoneno='$phoneno' ORDER BY tbltickets.fldtimestamp DESC";
        }        
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        while($record=mysqli_fetch_assoc($query)){
            $statement_company="SELECT * FROM tblterminals JOIN tbloperators ON tblterminals.fldoperatorid=tbloperators.fldoperatorid WHERE tblterminals.fldterminalid='$record[fldterminalid]' LIMIT 0,1";
            $query_company=mysqli_query($conn,$statement_company) or die(mysqli_error($conn));
            $company=mysqli_fetch_assoc($query_company);
            $record["fldoperator"]=$company["fldoperator"];   
            $trips[]=$record;
        }
        echo json_encode($trips);
    }
?>
