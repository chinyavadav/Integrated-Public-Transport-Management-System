<?php
	include("connection.php");
    if(isset($_GET["phoneno"])){
        $phoneno=mysqli_real_escape_string($conn,$_GET["phoneno"]);
        $statement="SELECT * FROM tbltrips WHERE fldterminalid='$phoneno' and fldstatus='' ORDER BY fldtimestamp DESC LIMIT 0,1";               
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        if(mysqli_num_rows($query)){
            $record=mysqli_fetch_assoc($query);
            $record["response"]="success";
        }else{
            $record["response"]="failed";
        }
        echo json_encode($record);
    }
?>