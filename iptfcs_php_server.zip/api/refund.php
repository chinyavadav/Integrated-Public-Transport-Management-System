<?php
    include("connection.php");
    header('Content-Type: application/json');
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $postdata = file_get_contents("php://input");
        if (isset($postdata)) {
            $record=json_decode($postdata);
            $ticketid=mysqli_real_escape_string($conn,$record->fldticketid);
            $amount=mysqli_real_escape_string($conn,$record->fldamount);
            $phoneno=mysqli_real_escape_string($conn,$record->fldphoneno);

            $statement_ticket="DELETE FROM tbltickets WHERE fldticketid='$ticketid'";      
            $query_ticket=mysqli_query($conn,$statement_ticket) or die(mysqli_error($conn));

            $statement_balance="UPDATE tblpassengers SET fldbalance=fldbalance+'$amount' WHERE fldphoneno='$phoneno'";      
            $query_balance=mysqli_query($conn,$statement_balance) or die(mysqli_error($conn));

            $response=array("response"=>"success");
        }else{
            $response=array("response"=>"failed");
        }
    }else{
        $response=array("response"=>"failed");
    }
    echo json_encode($response);
?>