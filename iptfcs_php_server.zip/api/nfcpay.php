<?php
    include("connection.php");
    header('Content-Type: application/json');
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $postdata = file_get_contents("php://input");
        $record=json_decode($postdata);
        if(isset($record->tripid) && isset($record->amount) && isset($record->tagid)) {
            $alphabet=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
            $ticketid="T".date('y').rand(100000,999999).$alphabet[rand(0,25)];    
            $tripid=mysqli_real_escape_string($conn,$record->tripid);
            $amount=mysqli_real_escape_string($conn,$record->amount);
            $tagid=base64_decode(mysqli_real_escape_string($conn,$record->tagid));

            $statement="SELECT * FROM tblpassengers WHERE fldnfc='$tagid' LIMIT 0,1";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            if(mysqli_num_rows($query)==1){
                $record=mysqli_fetch_assoc($query);
                $balance=$record["fldbalance"];
                $phoneno=$record["fldphoneno"];
                if($balance>=$amount){
                    $statement_balance="UPDATE tblpassengers SET fldbalance=fldbalance-'$amount' WHERE fldphoneno='$phoneno'";
                    $query_balance=mysqli_query($conn,$statement_balance) or die(mysqli_error($conn));
                    $timestamp_=time()."000";
                    $statement_tickets="INSERT INTO tbltickets VALUES('$ticketid','$tripid','$phoneno','$amount','wifi','$timestamp_','')";
                    $query_tickets=mysqli_query($conn,$statement_tickets) or die(mysqli_error($conn));

                    $response=array("response"=>"success");
                }else{
                    $response=array("response"=>"Insufficient funds!");
                }
            }else{
                $response=array("response"=>"Card is not registered!");
            }
        }else{
            $response=array("response"=>"Card is not registered!");
        }
        echo json_encode($response);
    }
    
?>