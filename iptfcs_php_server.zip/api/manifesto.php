<?php
	include("connection.php");
    $response=array();
    if(isset($_GET["tripid"])){
        $fares=array();
        $tripid=mysqli_real_escape_string($conn,$_GET["tripid"]);
        $statement="SELECT * FROM tbltickets WHERE fldtripid='$tripid' ORDER BY fldtimestamp DESC";      
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        while($record=mysqli_fetch_assoc($query)){
            $fares[]=$record;
        }
        $statement_trip="SELECT * FROM tbltrips WHERE fldtripid='$tripid'";     
        $query_trip=mysqli_query($conn,$statement_trip) or die(mysqli_error($conn));
        $response["trip"]=mysqli_fetch_assoc($query_trip);
        $response["fares"]=$fares;
        echo json_encode($response);        
    }
?>