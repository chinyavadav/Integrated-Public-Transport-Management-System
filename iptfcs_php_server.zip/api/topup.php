<?php
    include("connection.php");
    header('Content-Type: application/json');
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $postdata = file_get_contents("php://input");
        if (isset($postdata)) {
            $record=json_decode($postdata);
            $phoneno=mysqli_real_escape_string($conn,$record->phoneno);
            $amount=mysqli_real_escape_string($conn,$record->amount);
            $balance=$amount*100;
            $timestamp=time();
            $statement="INSERT INTO tbldeposits(fldphoneno,fldamount,fldtimestamp) VALUES('$phoneno','$balance','$timestamp')";                  
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));

            $statement_="UPDATE tblpassengers SET fldbalance=fldbalance+'$balance' WHERE fldphoneno='$phoneno'";                  
            $query_=mysqli_query($conn,$statement_) or die(mysqli_error($conn));

            $response=array("response"=>"success");
        }else{
            $response=array("response"=>"failed");
        }
    }else{
        $response=array("response"=>"failed");
    }
    echo json_encode($response);
?>