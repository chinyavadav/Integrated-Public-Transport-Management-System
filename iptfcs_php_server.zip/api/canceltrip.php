<?php
	include("connection.php");
    if(isset($_GET["tripid"])){
        $tripid=mysqli_real_escape_string($conn,$_GET["tripid"]);
        $statement_trip="UPDATE tbltrips SET fldstatus='complete' WHERE fldtripid='$tripid'";      
        $query_trip=mysqli_query($conn,$statement_trip) or die(mysqli_error($conn));
        $response=array("response"=>"success");
    }else{
        $response=array("response"=>"failed");
    }
    echo json_encode($response);
?>