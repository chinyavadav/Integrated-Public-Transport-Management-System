<?php
	$host="localhost";
	$uname="id7119356_root";
	$pwd="exchangeLIGAND@1";
	$dbase="id7119356_iptfcs";
	@$conn=mysqli_connect($host,$uname,$pwd,$dbase);
	if(!$conn){
		die();
	}else{
		header('Access-Control-Allow-Origin: *');
	}
?>
