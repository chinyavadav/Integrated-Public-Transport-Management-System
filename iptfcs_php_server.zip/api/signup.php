<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	    	$time=time();
	        $request = json_decode($postdata);

	        $phoneno=mysqli_real_escape_string($conn,$request->phoneno);
	        $firstname=mysqli_real_escape_string($conn,$request->firstname);
	        $lastname=mysqli_real_escape_string($conn,$request->lastname);
	        $status="Active";
	        $password=mysqli_real_escape_string($conn,$request->password);

        	$statement="INSERT INTO tblpassengers VALUES('$phoneno','$time','$firstname','$lastname','0','$status',MD5('$password'))";
        	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        	$response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

?>