<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	        $request = json_decode($postdata);
	        $terminalid=mysqli_real_escape_string($conn,$request->terminalid);
	        $from=mysqli_real_escape_string($conn,$request->from);
	        $to=mysqli_real_escape_string($conn,$request->to);
	        $amount=mysqli_real_escape_string($conn,$request->amount);
	        $amount=$amount*100;
	        $timestamp=time()."000";

	        $statement="INSERT INTO tbltrips (fldterminalid,fldamount,fldfrom,fldto,fldtimestamp,fldstatus) VALUES('$terminalid','$amount','$from','$to','$timestamp','')";
	        $query=mysqli_query($conn,$statement) or die(failed());
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>