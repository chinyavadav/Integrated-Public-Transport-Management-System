<?php
    include("connection.php");
    header('Content-Type: application/json');
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $postdata = file_get_contents("php://input");
        if (isset($postdata)) {
            $request = json_decode($postdata);
            $phoneno = mysqli_real_escape_string($conn,$request->phoneno);
            $phoneno=(int) $phoneno;
            $password =mysqli_real_escape_string($conn,$request->password);

            $statement="SELECT * FROM tblterminals WHERE fldterminalid='$phoneno' and fldpassword=MD5('$password') LIMIT 0,1";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            if(mysqli_num_rows($query)==1){
                $response=mysqli_fetch_assoc($query);
                $statement_operator="SELECT * FROM tbloperators WHERE fldoperatorid='$response[fldoperatorid]' LIMIT 0,1";
                $query_operator=mysqli_query($conn,$statement_operator) or die(mysqli_error($conn));
                $response['company']=mysqli_fetch_assoc($query_operator)["fldoperator"];
                $response['response']='success';                
            }else{
                $response=array("response"=>"failed");
            }
        } else{
            $response=array("response"=>"failed");
        }
        echo json_encode($response);
    }
?>