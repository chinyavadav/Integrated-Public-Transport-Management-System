<?php
	include("connection.php");
    $response=array();
    if(isset($_GET["phoneno"])){
        $fares=array();
        $phoneno=mysqli_real_escape_string($conn,$_GET["phoneno"]);

        $statement_trip="SELECT * FROM tbltrips WHERE fldterminalid='$phoneno' and fldstatus!='complete' LIMIT 0,1";      
        $query_trip=mysqli_query($conn,$statement_trip) or die(mysqli_error($conn));
        if(mysqli_num_rows($query_trip)==1){
            $tripid=mysqli_fetch_assoc($query_trip)["fldtripid"];
            $response["tripid"]=$tripid;
            $statement="SELECT * FROM tbltickets WHERE fldtripid='$tripid' ORDER BY fldtimestamp DESC";      
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            while($record=mysqli_fetch_assoc($query)){
                $fares[]=$record;
            }
            $response["fares"]=$fares;
            echo json_encode($response);
        }
    }
?>