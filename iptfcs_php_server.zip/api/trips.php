<?php
	include("connection.php");
    if(isset($_GET["type"]) && isset($_GET["phoneno"])){
        $trips=array();
        $type=mysqli_real_escape_string($conn,$_GET["type"]);
        $phoneno=mysqli_real_escape_string($conn,$_GET["phoneno"]);
        if($type=="today"){
            $today=date('Y-m-d');
            $timestamp=strtotime($today)+"000";
            $statement="SELECT * FROM tbltrips WHERE fldterminalid='$phoneno' and fldstatus='complete' and fldtimestamp>'$timestamp' ORDER BY fldtimestamp DESC";
        }else{
            $statement="SELECT * FROM tbltrips WHERE fldterminalid='$phoneno' and fldstatus='complete' ORDER BY fldtimestamp DESC";
        }        
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        while($record=mysqli_fetch_assoc($query)){             
            $trips[]=$record;
        }
        echo json_encode($trips);
    }
?>