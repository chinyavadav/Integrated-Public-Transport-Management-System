<?php
    include("connection.php");
    header('Content-Type: application/json');
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $postdata = file_get_contents("php://input");
        if (isset($postdata)) {
            $request = json_decode($postdata);
            $phoneno = mysqli_real_escape_string($conn,$request->phoneno);
            $password =mysqli_real_escape_string($conn,$request->password);
            $verifypassword =mysqli_real_escape_string($conn,$request->verifypassword);
            if($password==$verifypassword){
                $statement="UPDATE tblpassengers SET fldpassword=MD5('$password') WHERE fldphoneno='$phoneno'";
                $query=mysqli_query($conn,$statement) or die(error());
                $response=array("response"=>"success");
            }else{
                $response=array("response"=>"Password mismatch!");
            }
        } else{
            $response=array("response"=>"Server error!");
        }
        echo json_encode($response);
    }
    function error(){
        $response=array("response"=>"Server Error!");
        echo json_encode($response);
    }
?>