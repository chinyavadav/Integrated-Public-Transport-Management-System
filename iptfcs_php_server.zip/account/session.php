<?php
	@session_start();
	if(isset($_SESSION['email'])){
		$userEmail=$_SESSION['email'];
		$accessLevel=$_SESSION['accesslevel'];
		$mySession=$_SESSION['session'];
	}else{
		header("Location: ../index.php");
		exit;
	}
?>