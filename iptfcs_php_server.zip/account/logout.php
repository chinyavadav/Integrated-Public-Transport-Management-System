<?php
@session_start();
if(isset($_SESSION['email']))
{
	unset($_SESSION['email']);
	unset($_SESSION['accesslevel']);
	unset($_SESSION['session']);
	header("Location: ../login.php");
}else{
	header("Location: ../login.php");
}
?>