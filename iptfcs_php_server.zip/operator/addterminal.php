<?php
  include("session.php");include("../includes/connection.php");
  if($_SERVER["REQUEST_METHOD"]=="POST"){    
    $phoneno=$_POST["txtphoneno"];
    $name=$_POST["txtname"];

    $query="INSERT INTO tblterminals VALUES('$userSession[fldoperatorid]','$phoneno','$name','Active',MD5('$phoneno'))";
    $execute=mysqli_query($conn,$query) or die(duplicate());
    echo "<script>alert('Terminal has been successfully added!');window.location='terminals.php';</script>";
  }
  function duplicate(){
    echo "<script>alert('Operator could not be added!');window.location='terminals.php';</script>";
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PTFCS</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="../styles/img/favicon.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">
        <?php include("header.html"); include("sidebar.html"); ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><i class="fa fa-cab"></i> Add Terminal</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Details
                        </div>
                        <div class="panel-body">
                        <form method="post" action="">
                            <div class="form-group col-lg-6">
                                <label for="txtname">Phone No</label>
                                <input type="text" name="txtphoneno" class="form-control" pattern="[0-9]{10}" required placeholder="Phone No. e.g 0712345678"/>
                            </div> 
                            <div class="form-group col-lg-6">
                                <label for="txtoperator">Account Holder</label>
                                <input type="text" name="txtname" class="form-control" pattern="[A-Za-z0-9\s]{5,50}" required placeholder="Contact Person e.g. John Doe"/>
                            </div>  
                            <div class="form-group col-lg-12">
                                <button type="submit" name="cbosave" class="btn btn-primary btn-block"><i class="fa fa-save"></i> Save</button>
                            </div>
                        </form>
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
