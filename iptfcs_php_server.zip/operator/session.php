<?php
	@session_start();
	if(isset($_SESSION['session'])){
		$userSession=$_SESSION['session'];
	}else{
		header("Location: ../index.php");
		exit;
	}
?>