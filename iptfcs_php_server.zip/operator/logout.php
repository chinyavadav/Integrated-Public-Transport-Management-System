<?php
@session_start();
if(isset($_SESSION['session']))
{
	unset($_SESSION['session']);
	header("Location: ../index.php");
}else{
	header("Location: ../index.php");
}
?>